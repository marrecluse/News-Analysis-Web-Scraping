	PROJECT DESCRIPTION
	
This project is based on Web Scraping using Beautiful Soup. It basically fetch latest news headlines from three different tech news websites and display on the this single webpage. It will continue working until the source DOM is not changed. 

I have used flask for integrating UI, and as well as Bootstrap and Bulma for CSS designing. 


	PROJECT REQUIREMENTS
	
1) Working internet connection
2) Python, Pip, Flask, venv...
3) No need to download Bootstrap/Bulma, as I used CDN.
4) Make sure you are accessing the right port/host.


	Contact
	
Please feel free to contact, for any changes, improvements errors or the miscellaneous.

+92313 5857262
arehman02@protonmail.com

Best Regards,

Muhammad Abdul Rehman
@marrecluse
